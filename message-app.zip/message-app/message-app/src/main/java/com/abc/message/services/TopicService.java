package com.abc.message.services;

import com.abc.message.dto.TopicCreateDTO;

import java.util.UUID;

public interface TopicService {
    public Long createTopic(TopicCreateDTO topicCreateDTO);
}
