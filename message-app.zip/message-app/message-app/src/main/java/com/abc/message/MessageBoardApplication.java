package com.abc.message;

import com.abc.message.entities.Post;
import com.abc.message.entities.Topic;
import com.abc.message.entities.Vehicle;
import com.abc.message.repositories.PostRepository;
import com.abc.message.repositories.TopicRepository;
import com.abc.message.repositories.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.UUID;

@SpringBootApplication
@EnableJpaAuditing
public class MessageBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessageBoardApplication.class, args);
	}

}

@Component
class DemoCommandLineRunner implements CommandLineRunner{

	@Autowired
	private VehicleRepository vehicleRepository;

	@Autowired
	private TopicRepository topicRepository;

	@Autowired
	private PostRepository postRepository;

	@Override
	public void run(String... args) throws Exception {

		Vehicle audi = new Vehicle();
		audi.setId(UUID.randomUUID());
		audi.setVehicleIdentityNumber("Reg#1234");
		audi.setMake("Audi");
		audi.setModel("Q5");

		vehicleRepository.save(audi);

		Vehicle tesla = new Vehicle();
		tesla.setId(UUID.randomUUID());
		tesla.setVehicleIdentityNumber("Reg#6789");
		tesla.setMake("Tesla");
		tesla.setModel("Model S");

		vehicleRepository.save(tesla);

		Topic topic=new Topic();
		topic.setHeadingTitle("Entertainment");
		topic.setTopicName("Books");
		topic.setDescription("Book related messages under books topic");
		topic.setCreatedAt(LocalDate.now());
		topic.setDeletedAt(null);

		topicRepository.save(topic);

		Post post =new Post();

		post.setPost("Game of thrones ends");

		postRepository.save(post);

	}
}

