package com.abc.message.services;

import com.abc.message.dto.VehicleCreateDTO;
import com.abc.message.dto.VehicleQueryDTO;
import com.abc.message.dto.VehicleUpdateDTO;

import java.util.UUID;

public interface VehicleCommandService {

    public UUID createVehicle(VehicleCreateDTO vehicleCreateDTO);
    public VehicleQueryDTO updateVehicle(UUID id, VehicleUpdateDTO vehicleUpdateDTO);

}
