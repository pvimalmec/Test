package com.abc.message.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ApiModel(description = "Model to create a new Topic")
public class TopicCreateDTO {

    @NotNull
    @Size(max = 60, message = "Title of forum cannot have more than 30 characters")
    @ApiModelProperty(notes = "Title of forum", example = "Title under which the topics are classified")
    private String headingTitle;

    @NotNull
    @Size(max = 30, message = "TopicName cannot have more than 30  30 characters")
    @ApiModelProperty(notes = "Unique registration number for a vehicle", example = "Books")
    private String topicName;

    @NotNull
    @Size(max = 30, message = "Description cannot have more than 30 characters")
    @ApiModelProperty(notes = "Make of the vehicle", example = "About the topic in 30 words")
    private String description;


    public String getHeadingTitle() {
        return headingTitle;
    }

    public void setHeadingTitle(String headingTitle) {
        this.headingTitle = headingTitle;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @NotNull
    @Override
    public String toString() {
        return "TopicCreateDTO{" +
                ", headingTitle='" + headingTitle + '\'' +
                ", topicName='" + topicName + '\'' +
                ", description='" + description + '\'' +
                '}';
    }



}

