package com.abc.message.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigInteger;
import java.util.UUID;

@ApiModel(description = "Model to read Post information")
public class PostQueryDTO {

    @ApiModelProperty(notes = "Unique Id of the Post")
    private BigInteger id;

    @ApiModelProperty(notes = "Post name", example = "Game of thrones")
    private String post;


    public PostQueryDTO(BigInteger id, String post) {
        this.id = id;
        this.post = post;
    }

    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    @Override
    public String toString() {
        return "PostQueryDTO{" +
                "id=" + id +
                ", post='" + post + '\'' +
                '}';
    }
}
