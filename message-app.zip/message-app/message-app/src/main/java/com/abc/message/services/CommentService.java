package com.abc.message.services;


import com.abc.message.dto.CommentCreateDTO;
import com.abc.message.dto.CommentQueryDTO;
import com.abc.message.dto.PostCreateDTO;
import com.abc.message.entities.Comment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.math.BigInteger;
import java.util.List;

public interface CommentService {
    public BigInteger createComment(BigInteger id,CommentCreateDTO commentCreateDTO);
    public List<CommentQueryDTO> listAllCommentsByPostId(BigInteger topicId,BigInteger postId);

}
