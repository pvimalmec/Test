package com.abc.message.services;

import com.abc.message.dto.PostCreateDTO;
import com.abc.message.dto.PostQueryDTO;
import com.abc.message.dto.PostUpdateDTO;
import com.abc.message.entities.Post;
import com.abc.message.repositories.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityNotFoundException;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private PostRepository postRepository;

    @Override
    public BigInteger createPost(BigInteger id,  PostCreateDTO postCreateDTO) {
        Post newPost = new Post();

        newPost.setPost(postCreateDTO.getPost());
        return postRepository.save(newPost).getId();
    }

    @Override
    public List<PostQueryDTO> listAllPosts() {
        List<PostQueryDTO> postList = new ArrayList<>();
        postRepository.findAll().forEach(post -> {
            postList.add(new PostQueryDTO(post.getId(),post.getPost()));
        });

        if (postList.size() > 0){
            return postList;
        }else{
            throw new EntityNotFoundException("No post Found in the Database");
        }
    }

    @Override
    public Post getPost( BigInteger id) {
        if (postRepository.findById(id).isPresent()){
            Post fetchedPost = postRepository.findById(id).get();
            return  fetchedPost;
        }else{
            throw new EntityNotFoundException("Vehicle Id " + id.toString() + " not found in the database");
        }
    }

    @Override
    public PostQueryDTO updatePost(BigInteger id, PostUpdateDTO postUpdateDTO) {

        if (postRepository.findById(id).isPresent()){
            Post existingPost = postRepository.findById(id).get();
            existingPost.setPost(postUpdateDTO.getPost());


            Post updatedPost = postRepository.save(existingPost);
            return new PostQueryDTO(updatedPost.getId(), updatedPost.getPost());
        }else{
            throw new EntityNotFoundException("Post " + id.toString() + " not found in the database");
        }
    }

    @Override
    public BigInteger deletePost(BigInteger id, PostUpdateDTO postUpdateDTO) {

        if (postRepository.findById(id).isPresent()){
            Post existingPost = postRepository.findById(id).get();
            existingPost.setPost(postUpdateDTO.getPost());
            postRepository.delete(existingPost);
            return BigInteger.valueOf(0);
        }else{
            throw new EntityNotFoundException("Post " + id.toString() + " not found in the database");
        }
    }




}
