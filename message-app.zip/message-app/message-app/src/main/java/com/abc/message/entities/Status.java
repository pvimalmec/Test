package com.abc.message.entities;

public enum Status {
    FOR_SALE, SOLD
}
