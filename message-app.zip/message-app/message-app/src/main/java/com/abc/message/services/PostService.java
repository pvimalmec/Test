package com.abc.message.services;

import com.abc.message.dto.*;
import com.abc.message.entities.Post;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigInteger;
import java.util.List;
import java.util.UUID;

public interface PostService {
    public BigInteger createPost(BigInteger id, PostCreateDTO postCreateDTO);
    public List<PostQueryDTO> listAllPosts();
    public PostQueryDTO updatePost(BigInteger id, PostUpdateDTO postUpdateDTO);
    public BigInteger deletePost(BigInteger id, PostUpdateDTO postUpdateDTO);
    public Post getPost(BigInteger id);
}
