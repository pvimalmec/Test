package com.abc.message.controllers;

import com.abc.message.dto.TopicCreateDTO;
import com.abc.message.services.TopicService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "/api/topics")
@Api(tags = "Topic", value = "Topics", description = "Controller for Topics")
public class TopicController {

    @Autowired
    private TopicService topicService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @ApiOperation(value = "Create a new Topic")
    public ResponseEntity<Long> createTopic(@Valid @RequestBody TopicCreateDTO topicCreateDTO){
        return new ResponseEntity<>(topicService.createTopic(topicCreateDTO), HttpStatus.CREATED);
    }

}
