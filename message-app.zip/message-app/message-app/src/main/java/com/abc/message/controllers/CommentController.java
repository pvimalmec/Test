package com.abc.message.controllers;

import com.abc.message.dto.CommentCreateDTO;
import com.abc.message.dto.CommentQueryDTO;
import com.abc.message.exceptions.ResourceNotFoundException;
import com.abc.message.entities.Comment;
import com.abc.message.services.CommentService;
import com.abc.message.services.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import java.util.List;
import javax.validation.Valid;
import java.math.BigInteger;

@RestController
@RequestMapping(value = "/api/topics/{topicId}/posts/{postId}/comments")
@Api(tags = "Comments", value = "Comments", description = "Controller for Comments")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @Autowired
    private PostService postService;



    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "List all Comments")
    public ResponseEntity <List<CommentQueryDTO>> listAllCommentsByPostId(@PathVariable (value = "topicId") BigInteger topicId, @PathVariable (value = "postId") BigInteger postId){
        return new ResponseEntity<>(commentService.listAllCommentsByPostId(topicId,postId), HttpStatus.OK);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @ApiOperation(value = "Create a new Comment")
    public ResponseEntity<BigInteger> createComment(@PathVariable(value = "postId") BigInteger postId,
                                                 @RequestBody CommentCreateDTO commentCreateDTO){
        return new ResponseEntity<>(commentService.createComment(postId, commentCreateDTO), HttpStatus.CREATED);
    }



/*    @PutMapping("/posts/{postId}/comments/{commentId}")
    public Comment updateComment(@PathVariable (value = "postId") Long postId,
                                 @PathVariable (value = "commentId") Long commentId,
                                 @Valid @RequestBody Comment commentRequest) {
        if(!postRepository.existsById(postId)) {
            throw new ResourceNotFoundException("PostId " + postId + " not found");
        }

        return commentRepository.findById(commentId).map(comment -> {
            comment.setText(commentRequest.getText());
            return commentRepository.save(comment);
        }).orElseThrow(() -> new ResourceNotFoundException("CommentId " + commentId + "not found"));
    }

    @DeleteMapping("/posts/{postId}/comments/{commentId}")
    public ResponseEntity<?> deleteComment(@PathVariable (value = "postId") Long postId,
                                           @PathVariable (value = "commentId") Long commentId) {
        return commentRepository.findByIdAndPostId(commentId, postId).map(comment -> {
            commentRepository.delete(comment);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Comment not found with id " + commentId + " and postId " + postId));
    }*/
}
