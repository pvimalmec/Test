package com.abc.message.dto;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ApiModel(description = "Model to create a new Post")
public class PostCreateDTO {

    @NotNull
    @Size(max = 60, message = "Post cannot have more than 60 characters")
    @ApiModelProperty(notes = "Post under topic selected", example = "Game of thrones over")
    private String post;

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    @NotNull
    @Override
    public String toString() {
        return "PostCreateDTO{" +
                ", post='" + post + '\'' +
                '}';
    }

}

