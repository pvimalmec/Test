package com.abc.message.services;

import com.abc.message.dto.TopicCreateDTO;
import com.abc.message.entities.Topic;
import com.abc.message.repositories.TopicRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.UUID;

@Service
public class TopicServiceImpl implements TopicService {

    @Autowired
    private TopicRepository  topicRepository;

    @Override
    public Long createTopic(TopicCreateDTO topicCreateDTO) {
        Topic newTopic = new Topic();

        newTopic.setHeadingTitle(topicCreateDTO.getHeadingTitle());
        newTopic.setTopicName(topicCreateDTO.getTopicName());
        newTopic.setDescription(topicCreateDTO.getDescription());
        newTopic.setCreatedAt(LocalDate.now());
        newTopic.setDeletedAt(null);

        return topicRepository.save(newTopic).getId();
    }

}
