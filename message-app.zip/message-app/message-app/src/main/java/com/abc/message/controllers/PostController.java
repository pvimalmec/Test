package com.abc.message.controllers;

import com.abc.message.dto.PostQueryDTO;
import com.abc.message.dto.PostUpdateDTO;
import com.abc.message.exceptions.ResourceNotFoundException;
import com.abc.message.entities.Post;
import com.abc.message.dto.PostCreateDTO;
import com.abc.message.services.PostService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;


import javax.validation.Valid;
import java.math.BigInteger;
import java.util.List;

@RestController
@RequestMapping(value = "/api/topics/{id}/posts")
@Api(tags = "Posts", value = "Posts", description = "Controller for Posts")
public class PostController {

    @Autowired
    private PostService postService;


    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Get all Posts")
    public ResponseEntity<List<PostQueryDTO>>listAllPosts(){
        return new ResponseEntity<>(postService.listAllPosts(), HttpStatus.OK);
    }


    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @ApiOperation(value = "Create a new Post")
    public ResponseEntity<BigInteger> createPost(@PathVariable(value = "id") BigInteger id,
                                              @RequestBody PostCreateDTO postCreateDTO){
        return new ResponseEntity<>(postService.createPost(id, postCreateDTO), HttpStatus.CREATED);
    }

    @PutMapping(value = "/{PostId}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Update an existing Post")
    public ResponseEntity<PostQueryDTO> updatePost(@PathVariable(value = "PostId") BigInteger postId,
                                                         @RequestBody PostUpdateDTO postUpdateDTO){
        return new ResponseEntity<>(postService.updatePost(postId, postUpdateDTO), HttpStatus.OK);
    }


    @DeleteMapping(value = "/{PostId}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Create a delete Post")
    public ResponseEntity<BigInteger> deletePost(@PathVariable(value = "PostId") BigInteger postId,
                                                 @RequestBody PostUpdateDTO postUpdateDTO){
        return new ResponseEntity<>(postService.deletePost(postId, postUpdateDTO), HttpStatus.OK);
    }

/*    @PutMapping("/posts/{postId}")
    public Post updatePost(@PathVariable Long postId, @Valid @RequestBody Post postRequest) {
        return postRepository.findById(postId).map(post -> {
            post.setTitle(postRequest.getTitle());
            post.setDescription(postRequest.getDescription());
            post.setContent(postRequest.getContent());
            return postRepository.save(post);
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }


    @DeleteMapping("/posts/{postId}")
    public ResponseEntity<?> deletePost(@PathVariable Long postId) {
        return postRepository.findById(postId).map(post -> {
            postRepository.delete(post);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }*/

}