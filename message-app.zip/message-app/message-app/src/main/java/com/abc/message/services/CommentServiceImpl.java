package com.abc.message.services;

import com.abc.message.dto.CommentCreateDTO;
import com.abc.message.dto.CommentQueryDTO;
import com.abc.message.entities.Comment;
import com.abc.message.entities.Post;
import com.abc.message.repositories.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityNotFoundException;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Override
    public BigInteger createComment(BigInteger id, CommentCreateDTO commentCreateDTO) {
        Post post= new Post();
        post.setId(id);
        Comment newComment = new Comment();
        newComment.setPost(post);
        newComment.setComment(commentCreateDTO.getComment());
        return commentRepository.save(newComment).getId();

    }

    @Override
    public List<CommentQueryDTO> listAllCommentsByPostId(BigInteger topicId,BigInteger postId) {
        List<CommentQueryDTO> commentList = new ArrayList<>();

        commentRepository.findByPostId(postId).forEach(comment -> {
            commentList.add(new CommentQueryDTO(comment.getId(), comment.getComment()));
        });

        if (commentList.size() > 0){
            return commentList;
        }else{
            throw new EntityNotFoundException("No Comment Found in the Database");
        }
    }

}
