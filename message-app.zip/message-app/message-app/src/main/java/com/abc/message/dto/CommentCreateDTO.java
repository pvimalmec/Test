package com.abc.message.dto;


import com.abc.message.entities.Post;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ApiModel(description = "Model to create a new Comment")
public class CommentCreateDTO {

    @NotNull
    @Size(max = 60, message = "Comment cannot have more than 30 characters")
    @ApiModelProperty(notes = "Comment under topic selected", example = "Awesome!!")
    private String comment;

    private Post post;

    public Post getPost() {
        return post;
    }

    public void setPost(Post post) {
        this.post = post;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    @NotNull
    @Override
    public String toString() {
        return "CommentCreateDTO{" +
                ", comment='" + comment + '\'' +
                ", post='" + post + '\'' +
                '}';
    }

}

